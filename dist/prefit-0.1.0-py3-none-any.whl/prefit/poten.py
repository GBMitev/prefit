# %%
from .dependencies import *

def emo(r, params):
    '''
    Extended Morse Oscillator function taking inputs of internuclear distance (r) and a parameter dictionary (see inputs).

    Inputs:
        r          = internuclear distance, dtype = float, data structure = np.ndarray
        params     = parameter dictionary, must contain the following keys and values:

            "RE"   = equillibrium bond length, dtype = float, data structure = value
            "TE"   = potential minimum,        dtype = float, data structure = value
            "AE"   = asymptotic energy,        dtype = float, data structure = value
            "NL"   = left side sum limit,      dtype = int  , data structure = value
            "PL"   = left side Surkus param    dtype = int  , data structure = value
            "PR"   = right side Surkus param   dtype = int  , data structure = value
            "A[N]" = Morse parameter (see *)   dtype = float, data structure = value

            * Morse parameter coefficients are of format "A[N]" where [N] represents a natural number. 
            All [N] beneath the maximum [N] must exist e.g. [A0, A1, A2, A3], not [A0, A2, A3]

    Outputs:
        V          = EMO Potential Energy,     dtype = float, data structure = np.ndarray
    '''
    
    # Checking that r is an array
    if type(r) != np.ndarray:
        return "R needs to be of type:array"
    else:
        # Unpacking parameters
        RE, TE, AE, NL, PL, PR  = params["RE"], params["TE"], params["AE"], params["NL"], params["PL"], params["PR"]
        NL, PL, PR = int(NL), int(PL), int(PR)

        A = np.array([float(coeff) for key, coeff in params.items() if key.startswith("A")and key != "AE"])

        # Finding index where R_left changes to R_right
        R_step = [*filter(lambda x: x>= RE, list(r))][0]
        index_limit = list(r).index(R_step)

        # Calculating Surkus variable
        Surkus_conditions   = [r<= RE, r>RE]
        Surkus_values       = [(r**PL-RE**PL)/(r**PL+RE**PL),(r**PR-RE**PR)/(r**PR+RE**PR)]
        
        S = np.select(Surkus_conditions, Surkus_values)
        S_list = np.tile(S,(np.size(A),1))
        S_list = [sval**idx for idx, sval in enumerate(S_list)]

        # Forming Morse parameter (combining Surkus variable and expansion coefficients)
        Beta = S_list*A.reshape((-1,1))
        Beta = [np.where(idx >= index_limit,np.sum(BetaVal), np.sum(BetaVal[:NL+1])) for idx, BetaVal in enumerate(Beta.T)]

        #Calculating potential
        V = TE + (AE - TE)*(1-np.exp(Beta*(RE-r)))**2
        return V