# %%
from .dependencies import *
from .fit_emo import EMO, EMO_Parameters
from .poten import emo
# %%
def get_shape_set_permutations(PLs, PRs, NLs, NRs, SameP = True):
    shape_set_permuations = []
    for PL in PLs:
        for PR in PRs:
            for NL in NLs:
                for NR in NRs:
                    shape_set_permuations.append((PL,PR,NL,NR))
    
    df = pd.DataFrame(shape_set_permuations, columns=["PL", "PR","NL","NR"])
    df = df[df["NL"]<=df["NR"]]
    if SameP == True:
        df = df[df["PL"] == df["PR"]]
    
    return df.reset_index(drop = True)

def Optimize_EMO(R,V,cores,PLs,PRs,NLs,NRs,SameP=True,Vary = None, Bounds = None, method = "least_squares", full = False):
    df = get_shape_set_permutations(
        PLs,
        PRs,
        NLs,
        NRs,
        SameP=SameP)
    
    pandarallel.initialize(nb_workers = cores,progress_bar=True,verbose = 0)
    names = ["TE",
             "RE",
             "AE",
             "PL",
             "PR",
             "NL",
             "NR",
             *["A"+f"{i}" for i in range(max(NRs)+1)],
             "chi2_statistic",
             "pvalue"] 
    
    fits = pd.DataFrame(columns=[*names])
    df["EMO_Params"] = df.parallel_apply(lambda x:EMO_Parameters(
        R,
        V,
        PL = x["PL"],
        PR = x["PR"],
        NL = x["NL"],
        Order = x["NR"], 
        Vary = Vary, 
        Bounds = Bounds
        ), axis = 1)
    
    df[["Fitted","chi2","pvalue"]]     = df.apply(lambda x: x["EMO_Params"].fit_parameters(full=False,method = method), axis = 1, result_type = "expand")

    for fit in df[["Fitted"]].itertuples(index= False):
        fit = fit[0].transpose().reset_index(drop = True)
        fit.columns = fit.iloc[0].to_list()
        fit = fit.iloc[1:]
        fits = pd.concat([fits,fit])

    
    return fits.reset_index(drop = True) if full == False else df
# %%